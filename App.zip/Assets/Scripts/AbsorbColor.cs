using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AbsorbColor : MonoBehaviour
{
    private Renderer _renderer;
    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.tag == "cone")
        {
            _renderer.material.color  = other.gameObject.GetComponent<Renderer>().material.color;
        }
    }
}

using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.XR.Interaction.Toolkit;

public class HighlightAndSpawn : MonoBehaviour
{
    // Color highlightColor = Color.black;
    MeshRenderer _renderer;
    Color originalColor;
    bool isHighlighted = false;

    public AudioClip sfx;
    public ParticleSystem particleEffect;
    public GameObject coneRef;

    public GameObject location;
    public GameObject prefab;
    public GameObject sampleSizeCube;


    public InputActionReference cloneReference;
    public InputActionReference destroyReference;

    void Start()
    {
        _renderer = GetComponent<MeshRenderer>();

        originalColor = _renderer.material.color;
    }

    void Highlight()
    {
        originalColor = _renderer.material.color;

        isHighlighted = true;

        _renderer.material.color = Color.white;
    }

    void Dehighlight()
    {
        isHighlighted = false;

        _renderer.material.color = originalColor;
    }

    public void ToggleHighlight()
    {
        if (!isHighlighted)
        {
            Highlight();
        }
        else
        {
            Dehighlight();
        }
        // else dehighlight it
    }

    public void spawnObject()
    {
        Color currentColor = GetOriginalColor();
        GameObject clonedObject = Instantiate(prefab, location.transform.position, location.transform.rotation);
        clonedObject.transform.localScale = sampleSizeCube.transform.localScale;
        clonedObject.tag = "spawnedObject";
        //clonedObject.GetComponent<DuplicateObject>().enabled = true;
        // clonedObject.GetComponent<DestroyObject>().enabled = true;


        Rigidbody rigidBody = clonedObject.AddComponent<Rigidbody>();
        rigidBody.useGravity = true;

        SphereCollider sphereCollider = clonedObject.AddComponent<SphereCollider>();
        sphereCollider.isTrigger = false;

        Renderer meshRenderer = clonedObject.GetComponent<Renderer>();
        meshRenderer.material.color = currentColor;

        XRGrabInteractable grab = clonedObject.AddComponent<XRGrabInteractable>();
        grab.trackPosition = true;
        grab.throwOnDetach = true;
        // grab.interactionLayerMask = LayerMask.GetMask("Default");

        /*
        DuplicateObject duplicateScript = clonedObject.AddComponent<DuplicateObject>();
        duplicateScript._cloneReference = cloneReference;
        // clonedObject.GetComponent<DuplicateObject>().cloneReference = cloneReference;


        DestroyObject destroyScript = clonedObject.AddComponent<DestroyObject>();
        destroyScript._deleteReference = destroyReference;
        */

        Instantiate(particleEffect, clonedObject.transform.position, clonedObject.transform.rotation);
        AudioSource.PlayClipAtPoint(sfx, clonedObject.transform.position);
    }

    public Color GetOriginalColor()
    {
        return originalColor;
    }
}

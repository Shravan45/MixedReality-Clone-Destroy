﻿using UnityEngine;
using System.Collections;

public class DropColor : MonoBehaviour
{
    private Renderer _renderer;
    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.tag == "spawnedObject")
        {
            other.gameObject.GetComponent<Renderer>().material.color = _renderer.material.color;
        }
    }
}


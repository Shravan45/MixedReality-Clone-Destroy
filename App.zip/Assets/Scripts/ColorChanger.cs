using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.InputSystem.XR;
using UnityEngine.XR.Interaction.Toolkit;

public class ColorChanger : MonoBehaviour
{
    public InputActionReference _colorChangeReference;
    public GameObject coneObject;
    MeshRenderer _renderer;

    void Start()
    {
        _renderer = GetComponent<MeshRenderer>();
    }

    void Awake()
    {
        _colorChangeReference.action.started += TriggerPressed;
        _colorChangeReference.action.canceled += Detached;
    }

    private void TriggerPressed(InputAction.CallbackContext context)
    {
        Debug.Log("outside here");
        if (gameObject.GetComponent<XRGrabInteractable>().isHovered)
        {
            Debug.Log("inside here");
            _renderer.material.color = coneObject.GetComponent<Renderer>().material.color;
        }
    }

    private void Detached(InputAction.CallbackContext context)
    {
        // can specify custom behaviors for the original object when detached
    }
}

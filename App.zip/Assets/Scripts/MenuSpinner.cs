using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;

public class MenuSpinner : MonoBehaviour
{
    public float rotationSpeed = 10f; 
    public GameObject menuObject; 
    public GameObject leftController; 
    public InputActionReference joystickAction;


    private void OnEnable()
    {
        joystickAction.action.Enable();
    }


    private void OnDisable()
    {
        joystickAction.action.Disable();
    }


    void Update()
    {
        Vector2 joystickInput = joystickAction.action.ReadValue<Vector2>();
        float rotationAmount = joystickInput.x * rotationSpeed * Time.deltaTime;
        menuObject.transform.Rotate(Vector3.up, rotationAmount, Space.Self);
    }

}

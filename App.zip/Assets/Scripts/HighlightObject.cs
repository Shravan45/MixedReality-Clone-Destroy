using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.XR.Interaction.Toolkit;


public class HighlightObject : MonoBehaviour
{
    public Color highlightColor = Color.black;
    MeshRenderer _renderer;
    Color originalColor;
    bool isHighlighted = false;

    public AudioClip sfx;
    public ParticleSystem particleEffect;

    public GameObject location;
    public GameObject prefab;
    public GameObject sampleSizeCube;

    void Start()
    {
        // get a reference to the MeshRenderer
        _renderer = GetComponent<MeshRenderer>();

        // access and store the originalColor
        originalColor = _renderer.material.color;
    }

    void Highlight()
    {
        originalColor = _renderer.material.color;

        // set isHighlighted true
        isHighlighted = true;

        // change the material color to highlightColor
        _renderer.material.color = highlightColor;
    }

    void Dehighlight()
    {
        // set isHighlighted false
        isHighlighted = false;

        // change the material color to originalColor
        _renderer.material.color = originalColor;
    }

    public void ToggleHighlight()
    {
        // if not already highlighted, highlight the object
        if(!isHighlighted)
        {
            Highlight();
        }
        else
        {
            Dehighlight();
        }
        // else dehighlight it
    }

    public void spawnObject()

    {
        Color currentColor = GetOriginalColor();

        GameObject clonedObject = Instantiate(prefab, location.transform.position, location.transform.rotation);
        clonedObject.transform.localScale = sampleSizeCube.transform.localScale;
        


        Rigidbody rigidBody = clonedObject.AddComponent<Rigidbody>();
        rigidBody.useGravity = true;

        SphereCollider sphereCollider = clonedObject.AddComponent<SphereCollider>();
        sphereCollider.isTrigger = false;

        Renderer meshRenderer = clonedObject.GetComponent<Renderer>();
        meshRenderer.material.color = currentColor;

        XRGrabInteractable grab = clonedObject.AddComponent<XRGrabInteractable>();
        grab.trackPosition = true;
        grab.throwOnDetach = true;
        grab.interactionLayerMask = LayerMask.GetMask("Default");
        Instantiate(particleEffect, clonedObject.transform.position, clonedObject.transform.rotation);
        AudioSource.PlayClipAtPoint(sfx, clonedObject.transform.position);

    }

    public Color GetOriginalColor()
    {
        return originalColor;
    }
}

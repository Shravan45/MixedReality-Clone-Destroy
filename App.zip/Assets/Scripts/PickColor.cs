using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PickColor : MonoBehaviour
{
    public GameObject borderObject;
    public AudioClip newClip;
    Color highlightColor = Color.white;
    Color originalColor = Color.grey;

    private Renderer _renderer;
    MeshRenderer _borderRenderer;

    Color originalBorderColor;
    bool isHighlighted;

    private void Start()
    {
        _renderer = GetComponent<Renderer>();
        _borderRenderer = borderObject.GetComponent<MeshRenderer>();
        originalBorderColor = _borderRenderer.material.color;
    }

    void Highlight()
    {
        isHighlighted = true;
        AudioSource.PlayClipAtPoint(newClip, transform.position);
        _borderRenderer.material.color = highlightColor;
    }

    void Dehighlight()
    {
        isHighlighted = false;
        _borderRenderer.material.color = originalColor;
    }

    public void ToggleHighlight()
    {
        if (isHighlighted)
        {
            Dehighlight();
        }
        else
        {
            Highlight();
        }
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.tag == "cone")
        {
            other.gameObject.GetComponent<Renderer>().material.color = _renderer.material.color;
        }
    }
}
